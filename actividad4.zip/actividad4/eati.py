import sys

if len(sys.argv) == 3:
    texto = sys.argv[1]+" "+sys.argv[2]
    print(texto)    
else:
    print("error")
